/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author Asus
 */
import DAO.VehicleDAO;
import Model.Vehicle;

public class TollController{
    private VehicleDAO vehicleDAO;

    public TollController() {
        vehicleDAO = new VehicleDAO();
    }

    public boolean addVehicle(Vehicle vehicle){
        // VALIDASI KOSONG
        if (vehicle.getPlateNumber().trim().isEmpty()){
            return false;
        }
        // VALIDASI DUPLICATE
        if (vehicleDAO.isPlateExists(vehicle.getPlateNumber())){
            return false;
        }
        vehicleDAO.insertVehicle(vehicle);
        return true;
    }

    public void registerVehicle(Vehicle vehicle){
        if (vehicle.getPlateNumber().isEmpty()) {
            System.out.println("Plate number cannot be empty!");
            return;
        }
        vehicleDAO.insertVehicle(vehicle);
    }
}
