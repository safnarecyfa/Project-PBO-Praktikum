/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author Asus
 */
import DAO.TransactionDAO;
import Model.Transaction;

public class TransactionController {
    private TransactionDAO transactionDAO;
    public TransactionController() {
        transactionDAO = new TransactionDAO();
    }

    public void processTransaction(Transaction transaction) {
        transaction.completeTransaction();
        transactionDAO.insertTransaction(transaction);
    }
}