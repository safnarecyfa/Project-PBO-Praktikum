/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Asus
 */
import java.time.LocalDateTime;

public abstract class Vehicle {
    // Encapsulation
    private String plateNumber;
    private LocalDateTime entryTime;

    // Constructor
    public Vehicle(String plateNumber, LocalDateTime entryTime) {
        this.plateNumber = plateNumber;
        this.entryTime = entryTime;
    }

    // Getter
    public String getPlateNumber() {
        return plateNumber;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    // Abstract Method
    public abstract double calculateFare(long hours);

}
