/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Asus
 */
import Model.Payment.PaymentMethod;

import java.time.Duration;
import java.time.LocalDateTime;

public class Transaction {
    private Vehicle vehicle;
    private PaymentMethod paymentMethod;
    private String gateIn;

    public Transaction(Vehicle vehicle, PaymentMethod paymentMethod, String gateIn) {
        this.vehicle = vehicle;
        this.paymentMethod = paymentMethod;
        this.gateIn = gateIn;
    }

    public void completeTransaction()
    {
        double fare = calculateTotalFare();
        paymentMethod.processPayment(fare);
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public String getGateIn() {
        return gateIn;
    }
    
    public double calculateTotalFare(){
        Duration duration = Duration.between(vehicle.getEntryTime(),LocalDateTime.now());

        long hours = duration.toHours();

        if (hours == 0){
            hours = 1;
        }
        return vehicle.calculateFare(hours);
    }
}
