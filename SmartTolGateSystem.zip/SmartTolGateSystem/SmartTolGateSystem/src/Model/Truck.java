/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Asus
 */
import java.time.LocalDateTime;

public class Truck extends Vehicle {
    public Truck(String plateNumber, LocalDateTime entryTime) {
        super(plateNumber, entryTime);
    }

    @Override
    public double calculateFare(long hours) {
        return hours * 35000;
    }

}
