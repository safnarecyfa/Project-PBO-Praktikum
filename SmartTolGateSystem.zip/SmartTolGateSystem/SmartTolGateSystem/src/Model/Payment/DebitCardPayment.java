/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Payment;

/**
 *
 * @author Asus
 */
public class DebitCardPayment implements PaymentMethod {
    @Override
    public void processPayment(double amount) {

        System.out.println(
                "Debit Card payment successful: Rp" + amount
        );

    }

    @Override
    public String getPaymentName() {
        return "Debit Card";
    }

}
