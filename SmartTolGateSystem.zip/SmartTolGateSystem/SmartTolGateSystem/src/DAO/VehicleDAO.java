/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author Asus
 */
import Database.DBConnection;
import Model.Vehicle;

import Model.Car;
import Model.Bus;
import Model.Truck;

import java.time.LocalDateTime;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.swing.table.DefaultTableModel;

public class VehicleDAO {

    public boolean isPlateExists(String plateNumber) {
        String query = "SELECT * FROM vehicles " + "WHERE plate_number = ?";

        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, plateNumber);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void insertVehicle(Vehicle vehicle) {
        if (isPlateExists(vehicle.getPlateNumber())) {
            System.out.println("Plate number already registered!");
            return;
        }

        String query = "INSERT INTO vehicles " + "(plate_number, vehicle_type, entry_time, vehicle_status) " + "VALUES (?, ?, ?, ?)";
        try {
            Connection conn = DBConnection.getConnection();
            
            PreparedStatement ps = conn.prepareStatement(query);
            
            ps.setString(1,vehicle.getPlateNumber());
            ps.setString(2,vehicle.getClass().getSimpleName());
            ps.setObject(3, vehicle.getEntryTime());
            ps.setString(4,"INSIDE");
            
            System.out.println(vehicle.getPlateNumber());
            System.out.println(vehicle.getPlateNumber().length());
            
            ps.executeUpdate();
            
            System.out.println("Vehicle inserted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void getAllVehicles() {
        String query = "SELECT * FROM vehicles";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString("plate_number") + " - " + rs.getString("vehicle_type"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateVehicleStatus(int id, String status) {
        String query = "UPDATE vehicles " + "SET vehicle_status = ? " + "WHERE id = ?";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();

            System.out.println("Vehicle status updated!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle(int id) {
        String query = "DELETE FROM vehicles WHERE id = ?";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Vehicle deleted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Vehicle findVehicleByPlate(String plateNumber){
        String query = "SELECT * FROM vehicles " + "WHERE plate_number = ? " + "AND vehicle_status = 'INSIDE'";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1, plateNumber);

            ResultSet rs = ps.executeQuery();

            if (rs.next()){
                String type = rs.getString("vehicle_type");

                LocalDateTime entryTime =rs.getTimestamp("entry_time").toLocalDateTime();

                if (type.equals("Car")){
                    return new Car(plateNumber,entryTime);
                }else if (type.equals("Bus")){
                    return new Bus(plateNumber,entryTime);
                }else if (type.equals("Truck")){
                    return new Truck(plateNumber,entryTime);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public int getVehicleIdByPlate(String plateNumber) {
        String query = "SELECT id FROM vehicles WHERE plate_number = ?";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1, plateNumber);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    public void updateVehicleStatusByPlate(String plateNumber,String status) {
        String query = "UPDATE vehicles "+ "SET vehicle_status = ? "+ "WHERE plate_number = ?";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ps.setString(1, status);
            ps.setString(2, plateNumber);

            ps.executeUpdate();

            System.out.println("Vehicle status updated!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void showMonitoringData(DefaultTableModel model) {
        String query = "SELECT * FROM vehicles " + "WHERE vehicle_status = 'INSIDE'";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] row = {
                    rs.getString("plate_number"),
                    rs.getString("vehicle_type"),
                    rs.getTimestamp("entry_time"),
                    rs.getString("vehicle_status")
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void loadVehicleData(DefaultTableModel model) {
        String query = "SELECT * FROM vehicles";
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String plate = rs.getString("plate_number");
                String type = rs.getString("vehicle_type");
                String status = rs.getString("vehicle_status");
                model.addRow(new Object[]{
                    plate,
                    type,
                    status
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
