/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author Asus
 */
import Database.DBConnection;
import Model.Transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.time.LocalDateTime;
import java.sql.Timestamp;

import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

public class TransactionDAO {
    public void insertTransaction(Transaction transaction) {
        String query = "INSERT INTO transactions " + "(vehicle_id, fare, payment_method, gate_in, entry_time, exit_time) " + "VALUES (?, ?, ?, ?, ?, ?)";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            VehicleDAO vehicleDAO = new VehicleDAO();

            int vehicleId = vehicleDAO.getVehicleIdByPlate(transaction.getVehicle().getPlateNumber());

            ps.setInt(1, vehicleId);
            ps.setDouble(2, transaction.calculateTotalFare());
            ps.setString(3, transaction.getPaymentMethod().getPaymentName());
            ps.setString(4, transaction.getGateIn());
            ps.setObject(5, Timestamp.valueOf(transaction.getVehicle().getEntryTime()));
            ps.setObject(6, Timestamp.valueOf(LocalDateTime.now()));
            
            ps.executeUpdate();

            System.out.println("Transaction inserted!");
            ps.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void loadTransactionData(DefaultTableModel model) {
        String query =
                "SELECT v.plate_number, v.vehicle_type, " +
                "t.fare, t.payment_method, t.entry_time " +
                "FROM transactions t " +
                "JOIN vehicles v ON t.vehicle_id = v.id";
        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("plate_number"),
                    rs.getString("vehicle_type"),
                    rs.getDouble("fare"),
                    rs.getString("payment_method"),
                    rs.getTimestamp("entry_time")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
