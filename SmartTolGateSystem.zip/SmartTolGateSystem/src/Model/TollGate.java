/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Asus
 */
public class TollGate {

    private String gateName;

    public TollGate(String gateName) {
        this.gateName = gateName;
    }

    public String getGateName() {
        return gateName;
    }

}
