/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Asus
 */
import Model.Payment.PaymentMethod;

public class Transaction {

    private Vehicle vehicle;
    private PaymentMethod paymentMethod;
    private String gateIn;

    public Transaction(
            Vehicle vehicle,
            PaymentMethod paymentMethod,
            String gateIn
    ) {

        this.vehicle = vehicle;
        this.paymentMethod = paymentMethod;
        this.gateIn = gateIn;

    }

    public void completeTransaction() {

        double fare = vehicle.calculateFare();

        paymentMethod.processPayment(fare);

    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public String getGateIn() {
        return gateIn;
    }

}
