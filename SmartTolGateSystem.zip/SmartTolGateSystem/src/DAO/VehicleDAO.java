/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author Asus
 */
import Database.DBConnection;
import Model.Vehicle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class VehicleDAO {

    public boolean isPlateExists(
            String plateNumber
    ) {

        String query
                = "SELECT * FROM vehicles "
                + "WHERE plate_number = ?";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setString(1, plateNumber);

            ResultSet rs
                    = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }

    }

    public void insertVehicle(Vehicle vehicle) {

        if (isPlateExists(vehicle.getPlateNumber())) {

            System.out.println(
                    "Plate number already registered!"
            );

            return;
        }

        String query
                = "INSERT INTO vehicles "
                + "(plate_number, vehicle_type, vehicle_status) "
                + "VALUES (?, ?, ?)";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setString(
                    1,
                    vehicle.getPlateNumber()
            );

            ps.setString(
                    2,
                    vehicle.getClass().getSimpleName()
            );

            ps.setString(
                    3,
                    "INSIDE"
            );

            System.out.println(
                    vehicle.getPlateNumber()
            );

            System.out.println(
                    vehicle.getPlateNumber().length()
            );

            ps.executeUpdate();

            System.out.println(
                    "Vehicle inserted successfully!"
            );

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }

    public void getAllVehicles() {

        String query = "SELECT * FROM vehicles";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ResultSet rs
                    = ps.executeQuery();

            while (rs.next()) {

                System.out.println(
                        rs.getString("plate_number")
                        + " - "
                        + rs.getString("vehicle_type")
                );

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }

    public void updateVehicleStatus(int id, String status) {

        String query = "UPDATE vehicles " + "SET vehicle_status = ? " + "WHERE id = ?";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setString(1, status);

            ps.setInt(2, id);

            ps.executeUpdate();

            System.out.println(
                    "Vehicle status updated!"
            );

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }

    public void deleteVehicle(int id) {
        String query
                = "DELETE FROM vehicles WHERE id = ?";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println(
                    "Vehicle deleted successfully!"
            );

        } catch (SQLException e) {

            e.printStackTrace();

        }
    }

    public Vehicle findVehicleByPlate(
            String plate
    ) {

        String query
                = "SELECT * FROM vehicles "
                + "WHERE plate_number = ?";

        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setString(1, plate);

            ResultSet rs
                    = ps.executeQuery();

            if (rs.next()) {

                String type =
                    rs.getString(
                            "vehicle_type"
                    );

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return null;
    }
}
