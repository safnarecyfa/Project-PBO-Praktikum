/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author Asus
 */
import Database.DBConnection;
import Model.Transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionDAO {

    public void insertTransaction(
            Transaction transaction
    ) {

        String query
                = "INSERT INTO transactions "
                + "(vehicle_id, gate_in, entry_time, fare, payment_method) "
                + "VALUES (?, ?, ?, ?, ?)";
        try {

            Connection conn
                    = DBConnection.getConnection();

            PreparedStatement ps
                    = conn.prepareStatement(query);

            ps.setInt(1, 1);
            ps.setString(2, transaction.getGateIn());
            ps.setObject(3, transaction.getVehicle().getEntryTime());
            ps.setDouble(4, transaction.getVehicle().calculateFare());
            ps.setString(5, transaction.getPaymentMethod().getPaymentName());
            
            ps.executeUpdate();

            System.out.println(
                    "Transaction inserted!"
            );

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }

}
