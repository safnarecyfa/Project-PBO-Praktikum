/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

/**
 *
 * @author Asus
 */

import View.MainMenuView;

public class Main {
    
    public static void main(String[] args) {

        MainMenuView menu =
                new MainMenuView();

        menu.setVisible(true);

    }

}
