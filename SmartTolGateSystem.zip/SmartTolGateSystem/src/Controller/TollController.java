/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author Asus
 */
import DAO.VehicleDAO;
import Model.Vehicle;

public class TollController {

    private VehicleDAO vehicleDAO;

    public TollController() {

        vehicleDAO = new VehicleDAO();

    }

    public void addVehicle(
            Vehicle vehicle
    ) {

        vehicleDAO.insertVehicle(vehicle);

    }

    public void registerVehicle(
            Vehicle vehicle
    ) {

        if (vehicle.getPlateNumber().isEmpty()) {

            System.out.println(
                    "Plate number cannot be empty!"
            );

            return;
        }

        vehicleDAO.insertVehicle(vehicle);

    }

}
