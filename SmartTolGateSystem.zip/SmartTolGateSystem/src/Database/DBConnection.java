/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author Asus
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/smart_toll_system";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {

        try {

            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database Connected!");
            return conn;

        } catch (SQLException e) {

            System.out.println("Connection Failed!");
            e.printStackTrace();

            return null;
        }
    }
}
